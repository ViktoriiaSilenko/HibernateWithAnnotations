package ua.lviv.lgs;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

public class Main {

	public static void main(String[] args) {
		SessionFactory factory = new AnnotationConfiguration().configure()
				.addAnnotatedClass(Author.class).addAnnotatedClass(Book.class)
				.buildSessionFactory();
		Session session = factory.openSession();
		session.beginTransaction();
		
		// INSERT
//		session.save(new Author("John", "Tolkin", 125));
//		Author a = (Author) session.get(Author.class, 2);
//		System.out.println(a);
//		Book b = new Book("Hobbit");
//		b.setAuthor(a);
//		session.save(b);
		// ������ ����������, ��� ��� ����������� �����.
		// ���������� �������� ����� ����� � ��������� ����
//		Author a = new Author("John", "Tolkin", 23);
//		Book b1 = new Book("LOTR Fellowship");
//		Book b2 = new Book("LOTR Two Towers");
//		Book b3 = new Book("LOTR ROTK");
//		List<Book> books = new ArrayList<Book>();
//		books.add(b1);
//		books.add(b2);
//		books.add(b3);
//		a.setBooks(books);
//		session.save(a);
		
		//GET ALL
//		List<Book> list = session.createQuery("From Book").list();
//		for (Book book : list) {
//			System.out.println(book);
//		}
//		List<Author> list = session.createQuery("From Author where age > 100").list();
//		for (Author author : list) {
//			System.out.println(author);
//		}
		
		// DELETE FIRST METHOD
//		Book bdelete = new Book("LOTR ROTK");
//		bdelete.setId(5);
//		session.delete(bdelete);
		// DELETE SECOND METHOD
//		session.delete(session.get(Book.class, 4));
		
		session.getTransaction().commit();
		session.close();
		factory.close();
	}
}
